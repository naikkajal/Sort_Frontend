document.addEventListener("DOMContentLoaded", function() {
    console.log("Membership System Loaded");
});
